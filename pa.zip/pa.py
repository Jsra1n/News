import requests
from bs4 import BeautifulSoup
import os
import re

# 发送 HTTP 请求
response = requests.get('http://www.ctnews.com.cn/dongtai/node_1824.html')
response.encoding = 'utf-8'
data = response.text

# 使用 BeautifulSoup 解析 HTML
soup = BeautifulSoup(data, 'html.parser')

# 查找所有<div class="list__info">标签
list_infos = soup.find_all('div', class_='list__info')

# 循环遍历每个<div class="list__info">标签
for index, list_info in enumerate(list_infos):
    # 在每个<div class="list__info">标签内部查找<p class="list__summary">标签
    summary = list_info.find('p', class_='list__summary')
    # 获取<p class="list__summary">标签内的href属性值
    href = summary.find('a')['href']
    
    # 发送 HTTP 请求获取对应链接的内容
    response_article = requests.get(href)
    response_article.encoding = 'utf-8'
    article_data = response_article.text

    
    # 使用 BeautifulSoup 解析文章内容
    article_soup = BeautifulSoup(article_data, 'html.parser')
    
    # 提取文章标题
    title = article_soup.find('h1').text.strip()
    # 提取文章信息
    article_info = article_soup.find('div', class_='article-info').text.strip().replace('\n', ' ')
    # 提取文章内容
    article_content = article_soup.find('div', class_='article').find_all('p')
    content_html = ''
    for p in article_content:
        content_html += str(p)
    # 提取图片链接
    pic_url = ''

    
    article_tag = article_soup.find('div', class_='article')
    picurl_pattern = re.compile(r'<picurl>(.*?)</picurl>')
    picurl_matches = picurl_pattern.findall(str(article_tag))
    

    pic_url = picurl_matches[0]

    # 创建文件夹
    folder_path = str(index + 1)
    if not os.path.exists(folder_path):
        os.makedirs(folder_path)

    # 写入文件
    with open(os.path.join(folder_path, '文章标题.txt'), 'w', encoding='utf-8') as f:
        f.write(f'{title}\n')
    with open(os.path.join(folder_path, '文章信息.txt'), 'w', encoding='utf-8') as f:
        f.write(f' dwz  {article_info}\n')
    with open(os.path.join(folder_path, '文章内容.html'), 'w', encoding='utf-8') as f:
        f.write(content_html)
    with open(os.path.join(folder_path, '文章图片链接.txt'), 'w', encoding='utf-8') as f:
        f.write(f'{pic_url}\n')
    
    # 输出到终端显示
    print(f'文件夹名称: {folder_path}')
    print(f'文章标题: {title}')
    print(f'文章信息: {article_info}')
    print(f'文章内容: 已输出到文件')
    print(f'文章图片链接: {pic_url if pic_url else "未找到图片链接"}')
    print()
