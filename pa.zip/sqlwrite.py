import os
import pymysql
from datetime import datetime

# 连接数据库
conn = pymysql.connect(
    host='localhost',
    port=3306,
    user='root',
    password='123456',
    database='vuenewsdwz',
    charset='utf8mb4'
)

def get_next_id(cursor):
    cursor.execute("SELECT MAX(id) FROM xinwenxinxi")
    result = cursor.fetchone()[0]
    if result is None:
        return 1
    else:
        return result + 1

def insert_record(cursor, biaoti, tupian, neirong, tianjiaren):
    fenlei = 2
    dianjilv = 10
    addtime = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    next_id = get_next_id(cursor)
    sql = "INSERT INTO xinwenxinxi (id, biaoti, tupian, neirong, tianjiaren, fenlei, dianjilv, addtime) VALUES (%s, %s, %s, %s, %s, %s, %s, %s)"
    cursor.execute(sql, (next_id, biaoti, tupian, neirong, tianjiaren, fenlei, dianjilv, addtime))
    conn.commit()

def main():
    cursor = conn.cursor()

    for i in range(1, 11):
        folder_path = str(i)
        if not os.path.isdir(folder_path):
            continue
        
        # 读取文件内容
        with open(os.path.join(folder_path, '文章标题.txt'), 'r', encoding='utf-8') as f:
            biaoti = f.read().strip()

        with open(os.path.join(folder_path, '文章信息.txt'), 'r', encoding='utf-8') as f:
            tianjiaren = f.read().strip()

        with open(os.path.join(folder_path, '文章图片链接.txt'), 'r', encoding='utf-8') as f:
            tupian = f.read().strip()

        with open(os.path.join(folder_path, '文章内容.html'), 'r', encoding='utf-8') as f:
            neirong = f.read().strip()

        # 检查标题是否已存在
        cursor.execute("SELECT COUNT(*) FROM xinwenxinxi WHERE biaoti = %s", (biaoti,))
        if cursor.fetchone()[0] == 0:
            insert_record(cursor, biaoti, tupian, neirong, tianjiaren)
            print(f"成功写入文章：{biaoti}")
        else:
            print(f"文章已存在，跳过：{biaoti}")

    cursor.close()
    conn.close()

if __name__ == "__main__":
    main()
