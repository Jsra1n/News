const http = require('http');
const cheerio = require('cheerio');
const fs = require('fs');
const path = require('path');

// 发送 HTTP 请求
http.get('http://www.ctnews.com.cn/dongtai/node_1824.html', (response) => {
    let data = '';

    // 接收响应数据
    response.on('data', (chunk) => {
        data += chunk;
    });

    // 响应结束
    response.on('end', () => {
        // 将 HTML 传递给 Cheerio，以便进行解析
        const $ = cheerio.load(data);
        
        // 查找所有<div class="list__info">标签
        const listInfos = $('div.list__info');
        
        // 循环遍历每个<div class="list__info">标签
        listInfos.each((index, element) => {
            // 在每个<div class="list__info">标签内部查找<p class="list__summary">标签
            const summary = $(element).find('p.list__summary');
            // 获取<p class="list__summary">标签内的href属性值
            const href = summary.find('a').attr('href');
            
            // 发送 HTTP 请求获取对应链接的内容
            http.get(href, (response) => {
                let articleData = '';

                // 接收响应数据
                response.on('data', (chunk) => {
                    articleData += chunk;
                });

                // 响应结束
                response.on('end', () => {
                    // 将 HTML 传递给 Cheerio，以便进行解析
                    const $ = cheerio.load(articleData);
                    // 获取<div class="article">标签的内容
                    const articleContent = $('div.article');
                    
                    // 提取<h1>标签里的内容（文章标题）
                    const title = articleContent.find('h1').text().trim();
                    // 提取<div class="article-info">里的内容（文章信息）
                    const articleInfo = articleContent.find('div.article-info').text().trim().replace(/\n\s*/g, ' ');
                    // 提取整个内容
                    const contentMatch = articleData.match(/<!--enpcontent-->([\s\S]*?)<!--\/enpcontent-->/);
                    const content = contentMatch ? contentMatch[1] : '';
                    // 提取<picurl>标签的内容（文章图片链接）
                    const picUrlMatch = articleData.match(/<picurl>(.*?)<\/picurl>/s);
                    const picUrl = picUrlMatch ? picUrlMatch[1] : '';
                    
                    // 创建文件夹
                    const folderPath = path.join(__dirname, `${index + 1}`);
                    fs.mkdirSync(folderPath, { recursive: true });

                    // 写入文件
                    fs.writeFileSync(path.join(folderPath, '文章标题.txt'), `${title}`, 'utf8');
                    fs.writeFileSync(path.join(folderPath, '文章信息.txt'), `${articleInfo}`, 'utf8');
                    fs.writeFileSync(path.join(folderPath, '文章内容.html'), content, 'utf8');
                    fs.writeFileSync(path.join(folderPath, '文章图片链接.txt'), `${picUrl}`, 'utf8');
                    
                    // 打印到终端
                    console.log(`文章标题: ${title}`);
                    console.log(`文章信息: ${articleInfo}`);
                    console.log(`文章图片链接: ${picUrl}`);
                    console.log(`已写入文件夹: ${folderPath}`);
                    
                    // 请求 href 得到的内容输出为 index.html 到对应的编号的文件夹里
                    fs.writeFileSync(path.join(folderPath, 'index.html'), articleData, 'utf8');
                    console.log(`已写入 index.html 到文件夹: ${folderPath}`);
                });
            }).on('error', (error) => {
                console.error('Error fetching data:', error);
            });
        });
    });
}).on('error', (error) => {
    console.error('Error fetching data:', error);
});
